from django.apps import AppConfig

class DjangoStatsMiddlewareConfig(AppConfig):
    name = 'django_stats_middleware'
    verbose_name = 'Django Stats Middleware'
